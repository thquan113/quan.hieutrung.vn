<?php

use Illuminate\Support\Facades\Auth as FacadesAuth;
use Illuminate\Support\Facades\Broadcast;

// Broadcast::channel('chat', function ($user) {
//     return FacadesAuth::check();
// });