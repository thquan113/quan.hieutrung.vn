<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.coupon.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="py-3 d-flex justify-content-end">
                                <button type="submit" class="btn btn-outline-secondary">
                                    <i class="bi bi-plus-circle"></i>
                                    Thêm
                                </button>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="note text-end">
                                        <label class="text-danger fw-bolder">Trường có dấu (*) là bắt buộc!</label>
                                    </div>
                                    <div class="input mb-3">
                                        <label for="code" class="fw-bolder mb-1">
                                            Mã mới: <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" name="code" id="codes-input" class="form-control"
                                            placeholder="Nhập mã giảm giá mới" value="<?php echo e(old('code')); ?>">
                                        <?php echo $errors->first('code') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('code') . '</label>' : ''; ?>
                                    </div>
                                    <div class="input mb-3 position-relative">
                                        <label for="discount" class="fw-bolder mb-1">
                                            Giảm giá: <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" name="discount" id="discount"
                                            class="form-control input_discount input_number"
                                            placeholder="Nhập số % được giảm" value="<?php echo e(old('discount')); ?>">
                                        <label for="" class="text-muted position-absolute"
                                            style="top:55%; right:10px">%</label>
                                        <?php echo $errors->first('discount') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('discount') . '</label>' : ''; ?>
                                    </div>
                                    <div class="input mb-3">
                                        <label for="expires_at" class="fw-bolder mb-1">
                                            Ngày hết hạn:
                                        </label>
                                        <input type="date" name="expires_at" id="expires_at" class="form-control"
                                            placeholder="Gắn thẻ" value="<?php echo e(old('expires_at')); ?>">
                                        <?php echo $errors->first('expires_at') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('expires_at') . '</label>' : ''; ?>
                                        <p for="" class="text-warning" style="font-size: 12px">(!) Để
                                            trống coi
                                            như mã
                                            có hiệu lực vĩnh
                                            viễn</p>

                                    </div>

                                </div>
                                <div class="col-md-4"></div>
                            </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/pages/coupon/create.blade.php ENDPATH**/ ?>