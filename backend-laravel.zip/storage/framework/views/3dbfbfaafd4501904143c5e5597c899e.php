<?php
    if ($errors->any()) {
        foreach ($errors->all() as $error) {
            toastr()->warning($error);
        }
    }
?>
<?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/layouts/components/php.blade.php ENDPATH**/ ?>