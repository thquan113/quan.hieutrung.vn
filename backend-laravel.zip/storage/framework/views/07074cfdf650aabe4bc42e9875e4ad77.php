<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">
                        <div class="py-3 d-flex justify-content-end">
                            <a href="<?php echo e(route('admin.tag.create')); ?>">
                                <button type="button" class="btn btn-outline-secondary">
                                    <i class="bi bi-plus-circle"></i>
                                    Thêm thẻ mới
                                </button>
                            </a>
                        </div>
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th>Tên</th>
                                    <th>Cập nhật cuối</th>
                                    <th>ID</th>
                                    <th class="Action">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($tag->name); ?></td>
                                        <td> <?php echo e($tag->updated_at); ?></td>
                                        <td>#<?php echo e($key + 1); ?></td>
                                        <td class="Action">
                                            <div class="dropdown">
                                                <i class="bi bi-three-dots-vertical" data-bs-toggle="dropdown"
                                                    aria-expanded="false"></i>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item"
                                                            href="<?php echo e(route('admin.tag.edit', $tag->id)); ?>">
                                                            <i class="bi bi-pen"></i>Sửa</a></li>
                                                    <li> <?php echo '<form action="' . route(trim('admin.tag.remove'), trim( $tag->id)) . '" method="POST">' .
               csrf_field() . 
               method_field('delete') . 
               '<button class="dropdown-item"><i class="bi bi-trash"></i> Xoá</button></form>'; ?></li>

                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/pages/tag/index.blade.php ENDPATH**/ ?>