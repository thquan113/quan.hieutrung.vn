<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
        <li class="nav-item">
            <a class="nav-link <?php echo request()->routeIs('admin.dashboard.index') ? '' : 'collapsed'; ?>" href="<?php echo e(route('admin.dashboard.index')); ?>">
                <i class="bi bi-grid"></i>
                <span>Trang điều khiển</span>
            </a>
        </li>

        
        <li class="nav-item">
            <a class="nav-link <?php echo request()->routeIs('admin.product.index') ? '' : 'collapsed'; ?>" href="<?php echo e(route('admin.product.index')); ?>">
                <i class="bi bi-menu-button-wide"></i>
                <span>Sản phẩm</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo request()->routeIs('admin.order.index') ? '' : 'collapsed'; ?>" href="<?php echo e(route('admin.order.index')); ?>">
                <i class="bi bi-cart3"></i>
                <span>Đơn hàng</span>
            </a>
        </li><!-- End Profile Page Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo request()->routeIs('admin.category.index') ? '' : 'collapsed'; ?>" href="<?php echo e(route('admin.category.index')); ?>">
                <i class="bi bi-grid"></i>
                <span>Danh mục</span>
            </a>
        </li><!-- End Profile Page Nav -->
        <li class="nav-item">
            <a class="nav-link <?php echo request()->routeIs('admin.coupon.index') ? '' : 'collapsed'; ?>" href="<?php echo e(route('admin.coupon.index')); ?>">
                <i class="bi bi-percent"></i>
                <span>Mã giảm giá</span>
            </a>
        </li><!-- End Profile Page Nav -->


        <li class="nav-item">
            <a class="nav-link <?php echo request()->routeIs('admin.tag.index') ? '' : 'collapsed'; ?>" href="<?php echo e(route('admin.tag.index')); ?>">
                <i class="bi bi-tag"></i>
                <span>Thẻ</span>
            </a>
        </li><!-- End Profile Page Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo request()->routeIs('admin.slide.index') ? '' : 'collapsed'; ?>" href="<?php echo e(route('admin.slide.index')); ?>">
                <i class="bi bi-tv"></i>
                <span>Trượt</span>
            </a>
        </li><!-- End Profile Page Nav -->

        

        <li class="nav-heading mt-3">Kiểm soát truy cập</li>

        <li class="nav-item">
            <a class="nav-link <?php echo request()->routeIs('admin.messages.index') ? '' : 'collapsed'; ?>" href="<?php echo e(route('admin.messages.index')); ?>">
                <i class="bi bi-chat-dots"></i>
                <span>Hội thoại</span>
            </a>
        </li><!-- End Profile Page Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo request()->routeIs('admin.user.index') ? '' : 'collapsed'; ?>" href="<?php echo e(route('admin.user.index')); ?>">
                <i class="bi bi-people"></i>
                <span>Người dùng</span>
            </a>
        </li><!-- End Profile Page Nav -->

        <li class="nav-item">
            <a class="nav-link collapsed" href="pages-faq.html">
                <i class="bi bi-shield-lock"></i>
                <span>Vai trò</span>
            </a>
        </li><!-- End F.A.Q Page Nav -->

        

        <li class="nav-item mt-5">
            <a class="nav-link collapsed" href="<?php echo e(route('account.doLogout')); ?>">
                <i class="bi bi-box-arrow-in-right"></i>
                <span>Đăng xuất</span>
            </a>
        </li><!-- End Login Page Nav -->

        

        

    </ul>

</aside>
<?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/layouts/components/sidebar.blade.php ENDPATH**/ ?>