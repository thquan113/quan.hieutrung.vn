<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">
                        <div class="py-3 d-flex justify-content-end gap-2">
                            <a href="<?php echo e(route('admin.discount.reload')); ?>">
                                <button type="button" class="btn btn-outline-secondary">
                                    <i class="bi bi-arrow-clockwise"></i>
                                    Cài lại
                                </button>
                            </a>
                            <a href="<?php echo e(route('admin.discount.create')); ?>">
                                <button type="button" class="btn btn-outline-secondary">
                                    <i class="bi bi-plus-circle"></i>
                                    Thêm mã giảm giá
                                </button>
                            </a>

                        </div>
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th>Mã</th>
                                    <th>Hết hạn</th>
                                    <th>Cập nhật cuối</th>
                                    <th>Giảm giá</th>
                                    <th>ID</th>
                                    <th class="Action">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($discount->code); ?></td>
                                        <td><?php echo e($discount->expires_at == null ? 'Vĩnh viễn' : $discount->expires_at); ?></td>
                                        <td><?php echo e($discount->updated_at); ?></td>
                                        <td> <?php echo e($discount->discount); ?>%</td>
                                        <td>#<?php echo e($key + 1); ?></td>
                                        <td class="Action">
                                            <div class="dropdown">
                                                <i class="bi bi-three-dots-vertical" data-bs-toggle="dropdown"
                                                    aria-expanded="false"></i>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item"
                                                            href="<?php echo e(route('admin.discount.edit', $discount->id)); ?>">
                                                            <i class="bi bi-pen"></i>Sửa</a></li>
                                                    <li> <?php echo '<form action="' . route(trim('admin.discount.remove'), trim( $discount->id)) . '" method="POST">' .
               csrf_field() . 
               method_field('delete') . 
               '<button class="dropdown-item"><i class="bi bi-trash"></i> Xoá</button></form>'; ?></li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/pages/discount/index.blade.php ENDPATH**/ ?>