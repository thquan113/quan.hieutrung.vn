<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.product.update', $product->id)); ?>" method="post"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="py-3 d-flex justify-content-end">
                                <button type="submit" class="btn btn-outline-secondary">
                                    Cập nhật
                                </button>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="note text-end">
                                        <label class="text-danger fw-bolder">Trường có dấu (*) là bắt buộc!</label>
                                    </div>
                                    <div class="input mb-3">
                                        <label for="name" class="fw-bolder mb-1">
                                            Tên sản phẩm: <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" name="name" id="name" class="form-control"
                                            placeholder="Nhập tên sản phẩm" value="<?php echo e($product->name); ?>">
                                        <?php echo $errors->first('name') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('name') . '</label>' : ''; ?>
                                    </div>
                                    <div class="input mb-3">
                                        <label for="description" class="fw-bolder mb-1">
                                            Mô tả: <span class="text-danger">*</span>
                                        </label>
                                        <textarea class="form-control no-resize" name="description" rows="5" placeholder="Nhập mô tả ngắn" id=""><?php echo e($product->description); ?></textarea>
                                        <?php echo $errors->first('description') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('description') . '</label>' : ''; ?>
                                    </div>
                                    <div class="input mb-3 position-relative">
                                        <label for="price" class="fw-bolder mb-1">
                                            Giá: <span class="text-danger">*</span> (VNĐ)
                                        </label>
                                        <input type="text" name="price" id="price"
                                            class="form-control input_number" placeholder="Nhập giá tiền"
                                            value="<?php echo e($product->price); ?>">
                                        <label for="" class="text-muted position-absolute"
                                            style="top:55%; right:10px">VNĐ</label>
                                        <?php echo $errors->first('price') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('price') . '</label>' : ''; ?>
                                    </div>
                                    <div class="input mb-3 position-relative">
                                        <label for="weight" class="fw-bolder mb-1">
                                            Khối lượng: <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" name="weight" id="weight"
                                            class="form-control input_number" placeholder="Nhập khối lượng"
                                            value="<?php echo e($product->weight); ?>">
                                        <label for="" class="text-muted position-absolute"
                                            style="top:55%; right:10px">g</label>
                                        <?php echo $errors->first('weight') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('weight') . '</label>' : ''; ?>
                                    </div>
                                    <div class="input mb-3 position-relative">
                                        <label for="calories" class="fw-bolder mb-1">
                                            Năng lượng: <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" name="calories" id="calories"
                                            class="form-control input_number" placeholder="Nhập năng lượng"
                                            value="<?php echo e($product->calories); ?>">
                                        <label for="" class="text-muted position-absolute"
                                            style="top:55%; right:10px">calories</label>
                                        <?php echo $errors->first('calories') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('calories') . '</label>' : ''; ?>
                                    </div>
                                    <div class="input mb-3">
                                        <label for="category" class="fw-bolder mb-1">
                                            Danh mục:
                                        </label>
                                        <input type="text" name="category" id="categories-input"
                                            value="<?php echo e($product->category); ?>" class="form-control"
                                            placeholder="Nhập tên sản phẩm">
                                        
                                    </div>
                                    <div class="input mb-3">
                                        <label for="tag" class="fw-bolder mb-1">
                                            Thẻ:
                                        </label>

                                        <input type="text" name="tag" id="tags-input" class="form-control"
                                            placeholder="Gắn thẻ"
                                            value="<?php echo e($product->tags->pluck('name')->implode(', ')); ?>">

                                    </div>
                                    <div class="input mb-3">
                                        <label for="image" class="fw-bolder mb-1">
                                            Ảnh: <span class="text-danger">*</span>
                                        </label>
                                        <input type="file" name="image" id="image" class="form-control img-test">
                                        <input type="hidden" name="image1" id="image" class="form-control"
                                            value="<?php echo e($product->image); ?>">
                                        <?php echo $errors->first('image') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('image') . '</label>' : ''; ?>
                                    </div>
                                </div>
                                <div class="col-md-4"></div>
                            </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body mt-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="1" name="is_new"
                                id="flexCheckChecked" <?php echo e($product->is_new = 1 ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="flexCheckChecked">
                                Mới
                            </label>
                        </div>
                        <div class="form-check my-1">
                            <input class="form-check-input" type="checkbox" value="1" id="flexCheckDefault">
                            <label class="form-check-label" for="flexCheckDefault">
                                Nổi bật
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="1" name="is_bestseller"
                                id="flexCheckDefault" <?php echo e($product->is_bestseller = 1 ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="flexCheckDefault">
                                Đề xuất
                            </label>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/pages/product/edit.blade.php ENDPATH**/ ?>