<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="py-3 d-flex justify-content-end">
                            <a href="<?php echo e(route('admin.user.create')); ?>">
                                <button type="button" class="btn btn-outline-secondary">
                                    <i class="bi bi-plus-circle"></i>
                                    Thêm người dùng
                                </button>
                            </a>
                        </div>
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Ảnh</th>
                                    <th>Tên</th>
                                    <th>Cập nhật cuối</th>
                                    <th class="Action">Thao tác</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php echo e(Auth::user()->email == $user->email ? 'table-primary' : ''); ?>">
                                        <td>#<?php echo e($key + 1); ?></td>
                                        <td><img src="https://hoanghamobile.com/tin-tuc/wp-content/uploads/2024/01/meme-la-gi-18.jpg"
                                                alt="image" width="70"></td>
                                        <td>
                                            <?php echo e($user->user_name); ?>

                                            <?php echo Auth::user()->email == $user->email ? '<span class="text-danger fw-bold"> (me)</span>' : ''; ?>

                                        </td>
                                        <td> <?php echo e($user->updated_at); ?></td>
                                        <td class="Action">
                                            <div class="dropdown">
                                                <i class="bi bi-three-dots-vertical" data-bs-toggle="dropdown"
                                                    aria-expanded="false"
                                                    style="<?php echo e(Auth::user()->email == $user->email ? 'display:none ' : ''); ?>"></i>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item"
                                                            href="<?php echo e(route('admin.user.edit', $user->id)); ?>">
                                                            <i class="bi bi-pen"></i>Sửa</a></li>
                                                    <li><?php echo '<form action="' . route(trim('admin.user.remove'), trim( $user->id)) . '" method="POST">' .
               csrf_field() . 
               method_field('delete') . 
               '<button class="dropdown-item"><i class="bi bi-trash"></i> Xoá</button></form>'; ?></li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/pages/user/index.blade.php ENDPATH**/ ?>