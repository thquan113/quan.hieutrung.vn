<?php $__env->startSection('content'); ?>
    <?php
        $slide = $slide->first();
    ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex gap-3 p-3 pt-0 justify-content-end">
                    <form id="post-form" action="<?php echo e(route('admin.silde.remove', ['id' => $slide->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="button" class="btn btn-outline-success">Sửa</button>
                    </form>
                    <form id="post-form" action="<?php echo e(route('admin.silde.remove', ['id' => $slide->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-danger">Xoá</button>
                    </form>
                </div>
                <div class="card">
                    <div class="card-body mt-3 d-flex justify-content-between">
                        <div>
                            <label for="formFile" class="form-label">Ảnh</label>
                            <input class="form-control" type="file" id="formFile">
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/pages/slide/editSlide.blade.php ENDPATH**/ ?>