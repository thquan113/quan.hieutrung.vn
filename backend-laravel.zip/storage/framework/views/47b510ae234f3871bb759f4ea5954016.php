<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.user.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="py-3 d-flex justify-content-end">
                                <button type="submit" class="btn btn-outline-secondary">
                                    Thêm
                                </button>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="note text-end">
                                        <label class="text-danger fw-bolder">Trường có dấu (*) là bắt buộc!</label>
                                    </div>
                                    <div class="input mb-3">
                                        <label for="name" class="fw-bolder mb-1">
                                            Tên người dùng: <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" name="name" id="name" class="form-control"
                                            placeholder="Nhập tên sản phẩm" value="<?php echo e(old('name')); ?>">
                                        <?php echo $errors->first('name') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('name') . '</label>' : ''; ?>
                                    </div>
                                    <div class="input mb-3">
                                        <label for="email" class="fw-bolder mb-1">
                                            Mô tả: <span class="text-danger">*</span>
                                        </label>
                                        <input class="form-control no-resize" value="<?php echo e(old('email')); ?>" name="email"
                                            placeholder="Nhập email" id="">
                                        <?php echo $errors->first('email') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('email') . '</label>' : ''; ?>
                                    </div>
                                    <div class="input mb-3">
                                        <label for="email" class="fw-bolder mb-1">
                                            Số điện thoại: <span class="text-danger">*</span>
                                        </label>
                                        <input class="form-control no-resize input_number" value="<?php echo e(old('phone_number')); ?>"
                                            name="email" placeholder="Nhập số điện thoại" id="">
                                        <?php echo $errors->first('phone_number') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('phone_number') . '</label>' : ''; ?>
                                    </div>
                                    <div class="input mb-3">
                                        <label for="role" class="fw-bolder mb-1">
                                            Vai trò:
                                        </label>
                                        <select name="role" id="" class="form-control">
                                            <option value="agent">-- Người dùng</option>
                                            <option value="admin">-- Quản trị</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/pages/user/create.blade.php ENDPATH**/ ?>