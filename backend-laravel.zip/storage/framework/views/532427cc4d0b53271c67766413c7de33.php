<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.category.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="py-3 d-flex justify-content-end">
                                <button type="submit" class="btn btn-outline-secondary">
                                    <i class="bi bi-plus-circle"></i>
                                    Thêm danh mục mới
                                </button>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="note text-end">
                                        <label class="text-danger fw-bolder">Trường có dấu (*) là bắt buộc!</label>
                                    </div>
                                    <div class="input mb-3">
                                        <label for="name" class="fw-bolder mb-1">
                                            Tên danh mục: <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" name="name" id="name" class="form-control"
                                            placeholder="Nhập tên danh mục" value="<?php echo e(old('name')); ?>">
                                        <?php echo $errors->first('name') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('name') . '</label>' : ''; ?>
                                    </div>
                                    <div class="input mb-3">
                                        <label for="image" class="fw-bolder mb-1">
                                            Ảnh: <span class="text-danger">*</span>
                                        </label>
                                        <input type="file" name="image" id="image" class="form-control"
                                            value="<?php echo e(old('image')); ?>">
                                        <?php echo $errors->first('image') ? '<label class="text-danger">' .'<i class="bi bi-exclamation-circle mx-1"></i>' . $errors->first('image') . '</label>' : ''; ?>
                                    </div>
                                </div>
                                <div class="col-md-4"></div>
                            </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/pages/category/createCategory.blade.php ENDPATH**/ ?>