<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Ảnh</th>
                                    <th>Cập nhật cuối</th>
                                    <th class="disable Action">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>#<?php echo e($key + 1); ?></td>
                                        <td><img class="slide_img" src="<?php echo e($slide->image); ?>" alt="img" width="150">
                                        </td>
                                        <td><?php echo e($slide->updated_at); ?></td>
                                        <td class="Action">
                                            <div class="dropdown">
                                                <i class="bi bi-three-dots-vertical" data-bs-toggle="dropdown"
                                                    aria-expanded="false"></i>
                                                <ul class="dropdown-menu">
                                                    <form id="post-form"
                                                        action="<?php echo e(route('admin.silde.remove', ['id' => $slide->id])); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <li><a class="dropdown-item"
                                                                href="<?php echo e(route('admin.silde.edit.view', ['id' => $slide->id])); ?>">Sửa</a>
                                                        </li>

                                                        <li> <?php echo '<form action="' . route(trim('admin.slide.remove'), trim( $slide->id)) . '" method="POST">' .
               csrf_field() . 
               method_field('delete') . 
               '<button class="dropdown-item"><i class="bi bi-trash"></i> Xoá</button></form>'; ?></li>

                                                    </form>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/pages/slide/index.blade.php ENDPATH**/ ?>