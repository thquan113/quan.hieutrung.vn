<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="py-3 d-flex justify-content-end">
                            <a href="<?php echo e(route('admin.category.create')); ?>">
                                <button type="button" class="btn btn-outline-secondary">
                                    <i class="bi bi-plus-circle"></i>
                                    Tạo danh mục mới
                                </button>
                            </a>
                        </div>
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Ảnh</th>
                                    <th>Tên danh mục</th>
                                    <th>Cập nhật cuối</th>
                                    <th class="disable Action">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>#<?php echo e($key + 1); ?></td>
                                        <td><img class="category_img"
                                                src="<?php echo e(asset('storage/images/products/' . $category->image)); ?>"
                                                alt="img" width="150" style="max-height: 120px"></td>
                                        <td><?php echo e($category->name); ?></td>
                                        <td><?php echo e($category->updated_at); ?></td>
                                        <td class="Action">
                                            <div class="dropdown">
                                                <i class="bi bi-three-dots-vertical" data-bs-toggle="dropdown"
                                                    aria-expanded="false"></i>
                                                <ul class="dropdown-menu">
                                                    <form id="post-form"
                                                        action="<?php echo e(route('admin.category.remove', ['id' => $category->id])); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <li><a class="dropdown-item"
                                                                href="<?php echo e(route('admin.category.edit.view', ['id' => $category->id])); ?>">Sửa</a>
                                                        </li>

                                                        <li> <?php echo '<form action="' . route(trim('admin.category.remove'), trim( $category->id)) . '" method="POST">' .
               csrf_field() . 
               method_field('delete') . 
               '<button class="dropdown-item"><i class="bi bi-trash"></i> Xoá</button></form>'; ?></li>
                                                    </form>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/pages/category/index.blade.php ENDPATH**/ ?>