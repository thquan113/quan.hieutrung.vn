<?php $__env->startSection('content'); ?>
    
    
    <?php
        $currrentMessages = $messages->first();
        $currentUserId = $currrentMessages->first()->user_id;
    ?>

    <div id="message_container">
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-0" id="chat3" style="border-radius: 15px;">
                    <div class="card-body">
                        <div class="row pt-4">
                            <div class="col-md-6 col-lg-5 col-xl-4">

                                <div class="input-group rounded boxinput-chating mb-3" style="width: 95%;">
                                    <input type="search" class="form-control rounded" placeholder="Search"
                                        aria-label="Search" aria-describedby="search-addon" />
                                    <i class="bi bi-search"></i>
                                </div>

                                <div id="box-status" data-mdb-perfect-scrollbar-init
                                    style="position: relative; height: 450px">
                                    <ul class="list-unstyled mb-0" id="box-status-list">
                                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="p-2 border-bottom rounded-2 box-status-item"
                                                id="box-status-item<?php echo e($contents[0]->user->user_id); ?>">
                                                <a href="" class="d-flex justify-content-between">
                                                    <div class="d-flex flex-row">
                                                        <div>
                                                            <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava1-bg.webp"
                                                                alt="avatar" class="d-flex align-self-center me-3"
                                                                width="60">
                                                            <span class="badge bg-success badge-dot"></span>
                                                        </div>
                                                        <div class="pt-1">
                                                            <p class="fw-bold mb-0"><?php echo e($contents[0]->user->user_name); ?></p>
                                                            <p id="last_message" class="small text-muted">
                                                                <?php echo e($contents[0]->content); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="pt-1">
                                                        <p class="small text-muted mb-1">
                                                            <?php echo e(substr($contents[0]->created_at, 5, -3)); ?>

                                                        </p>
                                                        <span class="badge bg-danger rounded-pill float-end">3</span>
                                                    </div>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>

                            </div>

                            <div id="box-chating" class="col-md-6 col-lg-7 col-xl-8" style="height: 100%">

                                <div id="box-messages" class="pt-3 pe-3" data-mdb-perfect-scrollbar-init
                                    style="position: relative; height: 450px">
                                    <?php $__currentLoopData = $currrentMessages->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($content->role == 'admin'): ?>
                                            <div class="d-flex flex-row justify-content-end">
                                                <div>
                                                    <p class="small p-2 me-3 mb-1 text-white rounded-3 bg-primary">
                                                        <?php echo e($content->content); ?></p>
                                                    <p class="small me-3 mb-3 rounded-3 text-muted">
                                                        <?php echo e(substr($content->created_at, 5, -3)); ?>

                                                    </p>
                                                </div>
                                                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava1-bg.webp"
                                                    alt="avatar 1" style="width: 45px; height: 100%;">
                                            </div>
                                        <?php else: ?>
                                            <div class="d-flex flex-row justify-content-start">
                                                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava6-bg.webp"
                                                    alt="avatar 1" style="width: 45px; height: 100%;">
                                                <div>
                                                    <p class="small p-2 ms-3 mb-1 rounded-3 bg-body-tertiary">
                                                        <?php echo e($content->content); ?></p>
                                                    <p class="small ms-3 mb-3 rounded-3 text-muted float-end">
                                                        <?php echo e(substr($content->created_at, 5, -3)); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                                <div class="boxinput-chating">
                                    <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava1-bg.webp"
                                        alt="avatar 3" style="width: 40px; height: 100%;">
                                    <input type="text" class="form-control form-control-lg" id="send_message_input"
                                        placeholder="Type message" tabindex="1">
                                    <button tabindex="3"><i class="bi bi-image"></i></button>
                                    <button id="send_message_button" tabindex="2"><i class="bi bi-send-fill"></i></button>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <script>
        var scrollableDiv = document.getElementById("box-messages");
        scrollableDiv.scrollTop = scrollableDiv.scrollHeight;
    </script>
    <script>
        $('#send_message_button').on('click', function(e) {
            var message = $('#send_message_input').val();
            $('#send_message_input').val('')
            $.ajax({
                url: 'http://127.0.0.1:8000/admin/sendmessage',
                type: 'POST',
                data: {
                    userId: <?php echo e($currentUserId); ?>,
                    content: message,
                    role: 'admin',
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr(
                        'content')
                },
                success: function(response) {},
                error: function(xhr, status, error) {
                    console.log(xhr.responseText)
                    alert('Error sending message');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\This PC\OneDrive\Máy tính\Business\task\dine_hub_web_app\backend-laravel\resources\views/admin/pages/message/index.blade.php ENDPATH**/ ?>